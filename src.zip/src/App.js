import React from 'react'
import Screen from './Components/Screen'

function App() {
  return (
    <div>

      <Screen />

    </div>
  )
}

export default App